"""data manager"""
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


R_EARTH = 6371 # Задаем радиус Земли
MU = 398600.4415 # гравитационный параметр

def r_(r, v):
    return np.dot(r, v)
def dr_dt(r, v):
    return np.dot(v, v) - MU / np.linalg.norm(r)

def laplas_const(r, v):
    r__  = r_(r, v)
    dr_dt_ = dr_dt(r, v)
    f1 = r[0] * dr_dt_ - r__ * v[0]
    f2 = r[1] * dr_dt_ - r__ * v[1]
    f3 = r[2] * dr_dt_ - r__ * v[2]
    f = [f1, f2, f3]
    return f

def const_square(r, v):
    C1 = r[1] * v[2] - r[2] * v[1]
    C2 = r[2] * v[0] - r[0] * v[2]
    C3 = r[0] * v[1] - r[1] * v[0]
    C = [C1, C2, C3]
    return C

def pericenter(r, v):
    C = const_square(r, v)
    f = laplas_const(r, v)
    p = np.dot(C, C) / MU
    e = np.linalg.norm(f) / MU
    return p / (1 + e)

class DataCreate:
    """data with no good labels. just for test"""
    def __init__(self, n_samples):
        self.samples = n_samples
    def create(self, r_range=8000, v_range=8):
        data = np.random.randn(self.samples, 7)
        data[:, 0:3] = data[:, 0:3] * r_range
        data[:, 3:6] = data[:, 3:6] * v_range

        for i, vec in enumerate(data):
            per = pericenter(vec[:3], vec[3:6])
            if per < R_EARTH:
                data[i, 6] = 1
            else:
                data[i, 6] = 0
        data = Data(data, columns=["X", "Y", "Z", "dX", "dY" ,"dZ", "threat"])
        return data


class Data:
    """main dataclass"""
    def __init__(self, data=None, datapath=None, columns=["X", "Y", "Z", "dX", "dY" ,"dZ", "threat"]):
        if data is not None:
            self.data = pd.DataFrame(data, columns=columns)
        elif datapath:
            self.data = pd.read_csv(datapath)
        else:
            self.data = pd.DataFrame([], columns=columns)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data.iloc[idx]

    def get_label(self):
        return self.data["threat"]

    def std(self, columns=["X", "Y", "Z", "dX", "dY" ,"dZ"]):
        std = StandardScaler()
        data = std.fit_transform(self.data[columns])
        self.data[columns] = data

    def new_features(self):
        """add new column from X, Y, Z, dX, dY, dZ with rule"""
        data = self.data.copy()
        for feat in ["X", "Y", "Z", "dX", "dY" ,"dZ"]:
            data[feat + "2"] = data[feat] ** 2
            data[feat + "3"] = data[feat] ** 3
        self.data = data
        self.data.index = range(len(self.data))


    def augment(self):
        """simple augmentation"""
        if len(self.data.columns) > 7:
            #logger.exception("augment shoulde be before adding new columns!")
            return
        data = self.data.copy()
        data[["X", "Y", "Z", "dX", "dY" ,"dZ"]] = - data[["X", "Y", "Z", "dX", "dY" ,"dZ"]]
        self.data = self.data.append(data)
        self.data.index = range(len(self.data))

    def train_test_split(self, test_size=0.1):
        X_train, X_test = train_test_split(self.data, test_size=test_size)
        return Data(X_train, columns=self.data.columns), Data(X_test, columns=self.data.columns)


if __name__ == "__main__":
    data = DataCreate(20)
    print(data.create().data)

