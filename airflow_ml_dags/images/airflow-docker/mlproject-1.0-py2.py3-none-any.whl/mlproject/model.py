import pickle
from mlproject.data import Data
from sklearn.linear_model import LogisticRegression


class Model:
    def __init__(self, params={}):
        self.params = params
        self.model = LogisticRegression(**params)
        
    def train(self, data: Data, target="threat"):
        """train model"""
        X_train = data.data.drop(columns=[target])
        y_train = data.data[target]
        self.model.fit(X=X_train, y=y_train)
        
    def predict_score(self, data: Data, target="threat", proba=True):
        """predict"""
        X_val = data.data.drop(columns=[target])
        preds = self.model.predict_proba(X_val)[:, 1]
        return preds
    
    def save(self, name):
        """save model"""
        pickle.dump(self.model, open(name, 'wb'))
    
    def load(self, file_model):
        with open(file_model, "rb") as f:
            self.model = pickle.load(f)


if __name__ == "__main__":
    model = Model()
    print(model.model)